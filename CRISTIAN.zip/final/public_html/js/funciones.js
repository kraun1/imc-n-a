function init(){
	//Inicializamos el div de resultado no visible
	$("#resultado").hide();
}

function limpiar(){
	
	$("#txtPeso").val("");
	$("#txtTalla").val("");
}


function calcular(){
        
        var i=$("#NIÑO").val(); 
	var peso=$("#txtPeso").val();
	var talla=$("#txtTalla").val();
        
	//Validamos inicialmente

	if (document.getElementById("NIÑO").checked)
        {
        if (peso!="" && talla!=""){

		//Mostramos el div de resultados
		$("#resultado").show();
		//Obtenemos los valores ingresados por el usuario
		

		//Calculamos el imc
		talla=talla/100;
		var imc=peso/(talla*talla);

		var estado="";

		if (imc<.14){
			estado="Peso Bajo";
		}
		else if(imc>=14 && imc<17){
			estado="Peso Normal";
		}
		else if(imc>=17 && imc<19){
			estado="Sobrepeso";
		}
		else if(imc>=19 && imc<23){
			estado="Obesidad grado I";
		}
		else if(imc>=23 && imc<27){
			estado="Obesidad grado II";
		}
		else {
			estado="OBESIDAD GRADO 3";	
		}


		$("#imc").html(imc);
		$("#estado").html(estado);
		//Mostramos los resultados
	}
	else{
	            $("#resultado").hide();
	}
        }
        else{
           if (peso!="" && talla!=""){

		//Mostramos el div de resultados
		$("#resultado").show();
		//Obtenemos los valores ingresados por el usuario
		

		//Calculamos el imc
		talla=talla/100;
		var imc=peso/(talla*talla);

		var estado="";

		if (imc<.18){
			estado="Peso Bajo";
		}
		else if(imc>=18 && imc<25){
			estado="Peso Normal";
		}
		else if(imc>=25 && imc<27){
			estado="Sobrepeso";
		}
		else if(imc>=27 && imc<30){
			estado="Obesidad grado I";
		}
		else if(imc>=30 && imc<40){
			estado="Obesidad grado II";
		}
		else {
			estado="Peso Bajo";	
		}


		$("#imc").html(imc);
		$("#estado").html(estado);
		//Mostramos los resultados
	}
	else{
	            $("#resultado").hide();
	}
    }
}     

function cancelar(){
	$("#resultado").hide();
	limpiar();
}
init();
